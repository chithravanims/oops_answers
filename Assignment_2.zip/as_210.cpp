#include <iostream>
#include <cmath>
using namespace std;

class Shape {
public:
    virtual float area() = 0; // Pure virtual function
};

class Circle : public Shape {
    float r;
public:
    Circle(float radius) { r = radius; }
    float area() { return 3.14 * r * r; }
};

class Square : public Shape {
    float side;
public:
    Square(float s) { side = s; }
    float area() { return side * side; }
};

int main() {
    Shape* s1 = new Circle(5);
    Shape* s2 = new Square(4);

    cout << "Circle area: " << s1->area() << endl;
    cout << "Square area: " << s2->area() << endl;

    delete s1;
    delete s2;
    return 0;
}
