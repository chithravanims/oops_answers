#include <iostream>
using namespace std;

class slist{
    private:
    int arr[100];
    int size;
    public:
    slist(){
        size = 0;
    }
    void add(int value){
        arr[size++]=value;
    }

    void remove(){
        if(size>0){
            size--;
        }
        else{
            cout<<"List is empty, cannot remove element."<<endl;
        }
    }
    void display(){
        for(int i=0;i<size;i++){
            cout<<arr[i]<<" ";
        }
        cout<<endl;
    }

    int getSize(){
        return size;
    }
};

int main(){
    slist list;
    list.add(10);
    list.add(20);
    list.add(30);
    cout<<"List elements: ";
    list.display();
    list.remove();
    cout<<"List elements after removal: ";  
    list.display();
    cout<<"Current size of the list: "<<list.getSize()<<endl;
    return 0;
}