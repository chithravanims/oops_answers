#include <iostream>
using namespace std;


class dict {
    string keys[100];
    string values[100];
    int size;

public:

    dict() {
        size = 0;
    }

    void add(string key, string value) {
        keys[size] = key;
        values[size] = value;
        size++;
    }


    void search(string key) {
        for (int i = 0; i < size; i++) {
            if (keys[i] == key) {
                cout << "Key: " << key << ", Value: " << values[i] << endl;
                return;
            }
        }
        cout << "Key not found!" << endl;
    }

    void display() {
        cout << "\nAll key-value pairs:\n";
        for (int i = 0; i < size; i++)
            cout << keys[i] << " : " << values[i] << endl;
    }
};


int main() {
    dict d; 
    d.add("name", "Alice");
    d.add("age", "21");
    d.add("city", "Chennai");
    d.search("name");
    d.search("class"); 
    d.display();
    return 0;
}
