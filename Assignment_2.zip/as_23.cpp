#include <iostream>
using namespace std;

class Shape {
protected:
    float length, breadth;

public:
    void setDimensions(float l, float b) {
        length = l;
        breadth = b;
    }
};

class Rectangle : public Shape {
public:
    float area() { return length * breadth; }
    float perimeter() { return 2 * (length + breadth); }
};

int main() {
    Rectangle rect;
    rect.setDimensions(4, 5);
    cout << "Area: " << rect.area() << endl;
    cout << "Perimeter: " << rect.perimeter() << endl;
    return 0;
}
