#include <iostream>
using namespace std;

class Sorter {
    int arr[100], n;
public:
    void input() {
        cout << "Enter number of elements: ";
        cin >> n;
        cout << "Enter elements: ";
        for (int i = 0; i < n; i++) cin >> arr[i];
    }

    void bubbleSort() {
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (arr[j] > arr[j + 1])
                    swap(arr[j], arr[j + 1]);
    }

    void display() {
        cout << "Sorted array: ";
        for (int i = 0; i < n; i++) cout << arr[i] << " ";
        cout << endl;
    }
};

int main() {
    Sorter s;
    s.input();
    s.bubbleSort();
    s.display();
    return 0;
}
