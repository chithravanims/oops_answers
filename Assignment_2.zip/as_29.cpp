#include <iostream>
using namespace std;

class BankAccount {
private:
    string name;
    int accNo;
    float balance;

public:
    BankAccount(string n, int a, float b) : name(n), accNo(a), balance(b) {}

    void deposit(float amt) { balance += amt; }
    void withdraw(float amt) {
        if (amt <= balance) balance -= amt;
        else cout << "Insufficient balance.\n";
    }
    void display() {
        cout << "Name: " << name << ", Account No: " << accNo
             << ", Balance: " << balance << endl;
    }
};

int main() {
    BankAccount acc("John", 101, 5000);
    acc.deposit(2000);
    acc.withdraw(1000);
    acc.display();
    return 0;
}
