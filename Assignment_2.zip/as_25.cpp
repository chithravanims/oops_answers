#include <iostream>
using namespace std;

class person{
    public:
    void display(){
        cout<<"This is a person."<<endl;
    }
};

class athlete{
    public:
    void display(){
        cout<<"This is an athlete."<<endl;
    }
};

class sportsperson : public person, public athlete{
    public:
    void show(){
        person::display();
        athlete::display();
        cout<<"This is a sportsperson."<<endl;
    }
};

int main(){
    sportsperson sp;
    sp.show();
    return 0;
}