#include <iostream>
using namespace std;

class Sports;

class Student {
    int marks;
public:
    Student(int m) : marks(m) {}
    friend void showTotal(Student, Sports);
};

class Sports {
    int score;
public:
    Sports(int s) : score(s) {}
    friend void showTotal(Student, Sports);
};

void showTotal(Student s, Sports sp) {
    cout << "Total performance: " << s.marks + sp.score << endl;
}

int main() {
    Student st(80);
    Sports sp(20);
    showTotal(st, sp);
    return 0;
}
