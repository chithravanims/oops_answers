#include <iostream>
using namespace std;

class Person {
private:
    string name;  

public:
    void setName() {
        cout << "Enter name: ";
        cin >> name;
    }

    string getName() {
        return name;
    }
};

class Employee : public Person {
private:
    int id;

public:
    void setID() {
        cout << "Enter ID: ";
        cin >> id;
    }

    int getID() {
        return id;
    }
};

class Manager : public Employee {
private:
    float salary;

public:
    void setSalary() {
        cout << "Enter salary: ";
        cin >> salary;
    }

    float getSalary() {
        return salary;
    }

    void display() {
        cout << "Name: " << getName()
             << ", ID: " << getID()
             << ", Salary: " << getSalary() << endl;
    }
};


int main() {
    Manager m;
    m.setName();
    m.setID();
    m.setSalary();
    m.display();
    return 0;
}

