#include <iostream>
using namespace std;

class Math {
public:
    int add(int a, int b) { return a + b; }
    double add(double a, double b) { return a + b; } // Overloading
};

class Base {
public:
    virtual void show() { cout << "Base class show()\n"; }
};

class Derived : public Base {
public:
    void show() override { cout << "Derived class show()\n"; } // Overriding
};

int main() {
    Math m;
    cout << m.add(2, 3) << endl;
    cout << m.add(2.5, 3.6) << endl;

    Base* b = new Derived();
    b->show();
    delete b;
    return 0;
}
